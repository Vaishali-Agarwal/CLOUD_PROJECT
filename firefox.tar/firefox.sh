read -p "Enter username :  "  username
ssh -X $username@192.168.122.78 firefox
